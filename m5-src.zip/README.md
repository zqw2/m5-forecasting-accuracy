# Python version 
``` 
3.8
```

# Install Dependencies
```
pip install -r requirements.txt
```


# How to run
```
cd %project_root_dir%  
python run.py
``` 

# run result
```
cd result dir ,then you will see
```